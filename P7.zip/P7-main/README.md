# P7 VIEW KOPERASI

Laporan praktikum basis data mengenai penggunaan VIEW pada MySQL.

## Materi:
- CREATE VIEW
- JOIN 2 tabel
- JOIN 3 tabel
- SELECT VIEW
- UPDATE VIEW
- DROP VIEW

## Database:
koperasi

## Tools:
- XAMPP
- phpMyAdmin
- CMD MySQL
