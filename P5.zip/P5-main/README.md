# 📊 DATABASE KOPERASI (MySQL / MariaDB - XAMPP)

Project ini merupakan latihan database koperasi menggunakan MariaDB (XAMPP) melalui CMD. Database ini berisi 4 tabel utama: anggota, simpanan, pinjaman, dan angsuran.

---

# ⚙️ INFORMASI PROJECT
- Nama Database : koperasi  
- DBMS : MariaDB (XAMPP)  
- Tools : CMD MySQL  
- Bahasa : SQL  

---

# 🗂️ STRUKTUR TABEL

## 1. Tabel ANGGOTA
Menyimpan data anggota koperasi.

```sql
id_anggota INT (PRIMARY KEY)
nama VARCHAR(50)
alamat VARCHAR(100)
no_hp VARCHAR(15)
